export declare enum Action {
    CREATE = 0,
    QUEUE = 1,
    CANCEL = 2,
    SKIP = 3,
    UNRECOGNIZED = -1
}
export interface BaseCondition {
    readableDataKey?: string;
    action?: Action;
    /** a UUID defining the OR group for this condition */
    orGroupId?: string;
    expression?: string;
}
export declare abstract class Condition {
    base: BaseCondition;
    constructor(base: BaseCondition);
}
