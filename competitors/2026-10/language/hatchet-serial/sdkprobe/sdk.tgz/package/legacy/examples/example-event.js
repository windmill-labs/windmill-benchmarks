"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const sdk_1 = __importDefault(require("../../sdk"));
const hatchet = sdk_1.default.init();
// Push a single event (example)
hatchet.events.push('user:create', {
    test: 'test',
});
// Example events to be pushed in bulk
const events = [
    {
        payload: { test: 'test1' },
        additionalMetadata: { user_id: 'user1', source: 'test' },
    },
    {
        payload: { test: 'test2' },
        additionalMetadata: { user_id: 'user2', source: 'test' },
    },
    {
        payload: { test: 'test3' },
        additionalMetadata: { user_id: 'user3', source: 'test' },
    },
];
// Bulk push the events and compare the keys
hatchet.events
    .bulkPush('user:create:bulk', events)
    .then((result) => {
    const returnedEvents = result.events;
    const keysMatch = returnedEvents.every((returnedEvent) => {
        const expectedKey = `user:create:bulk`;
        return returnedEvent.key === expectedKey;
    });
    if (keysMatch) {
        console.log('All keys match the original events.');
    }
    else {
        console.log('Mismatch found between original events and returned events.');
    }
})
    .catch((error) => {
    console.error('Error during bulk push:', error);
});
