"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseGrpcTarget = parseGrpcTarget;
exports.grpcTargetBaseUrl = grpcTargetBaseUrl;
/**
 * IP literal checks with the same outcome as Node's `net.isIPv4` and `net.isIPv6` for the
 * addresses a gRPC target can name. They are written here rather than imported from `net`
 * because the fetch transport parses targets too, and it runs where `net` does not exist.
 */
const IPV4 = /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;
const HEX_GROUP = /^[0-9a-fA-F]{1,4}$/;
/** What Node accepts after the one `%` of a zone id: nonempty, letters, digits, `-`, `.` and `:`. */
const ZONE_ID = /^[0-9a-zA-Z\-.:]+$/;
function isIPv4(address) {
    return IPV4.test(address);
}
function isIPv6(address) {
    const zoneAt = address.indexOf('%');
    if (zoneAt !== -1 && !ZONE_ID.test(address.slice(zoneAt + 1))) {
        return false;
    }
    const literal = zoneAt === -1 ? address : address.slice(0, zoneAt);
    const halves = literal.split('::');
    if (halves.length > 2) {
        return false;
    }
    // An embedded IPv4 address counts as two groups and may only end the whole literal: the
    // last item of the part after `::`, or of the only part when there is no `::`.
    const groups = (part, endsLiteral) => {
        if (part === '') {
            return [];
        }
        const items = part.split(':');
        const last = items[items.length - 1];
        if (endsLiteral && last.includes('.')) {
            if (!isIPv4(last)) {
                return null;
            }
            items.splice(items.length - 1, 1, '0', '0');
        }
        return items.every((item) => HEX_GROUP.test(item)) ? items : null;
    };
    const head = groups(halves[0], halves.length === 1);
    const tail = halves.length === 2 ? groups(halves[1], true) : [];
    if (!head || !tail) {
        return false;
    }
    const count = head.length + tail.length;
    return halves.length === 2 ? count < 8 : count === 8;
}
/** The port grpc-js dials when a target names none. */
const DEFAULT_PORT = 443;
/*
 * grpc-js parses a target as `scheme:` `//authority/` `path`, all but the path optional; a
 * scheme it has no resolver for (which is what `host:port` looks like) makes the whole string a
 * `dns` path.
 */
const URI_REGEX = /^(?:([A-Za-z0-9+.-]+):)?(?:\/\/([^/]*)\/)?(.+)$/;
const RESOLVER_SCHEMES = new Set(['dns', 'ipv4', 'ipv6', 'unix']);
/**
 * Parses the target forms grpc-js accepts for `host_port`, so the unary transport dials the
 * same endpoint the streaming channel does: `host:port`, `dns:host:port`, `dns:///host:port`,
 * `ipv4:address:port` and `ipv6:[address]:port` (the first address of an address list). A
 * missing port is grpc-js's default, 443. `unix:` sockets and a `dns://nameserver/` authority
 * have no HTTP/2 equivalent here and are refused with a clear error.
 */
function parseGrpcTarget(target) {
    var _a;
    const match = URI_REGEX.exec(target);
    if (!match) {
        throw new Error(`host_port ${JSON.stringify(target)} is not a gRPC target`);
    }
    const [, rawScheme, authority, rawPath] = match;
    const known = rawScheme !== undefined && RESOLVER_SCHEMES.has(rawScheme);
    const scheme = known ? rawScheme : 'dns';
    const path = known ? rawPath : target;
    if (scheme === 'unix') {
        throw new Error(`host_port ${JSON.stringify(target)}: unix domain socket targets are not supported by the unary transport; use a host:port target`);
    }
    if (known && authority) {
        throw new Error(`host_port ${JSON.stringify(target)}: a target-specific DNS server is not supported by the unary transport; use dns:///host:port`);
    }
    const address = scheme === 'dns' ? path : path.split(',')[0];
    const hostPort = splitHostPort(address);
    if (!hostPort) {
        throw new Error(`host_port ${JSON.stringify(target)} is not a valid host and port`);
    }
    if (scheme === 'ipv4' && !isIPv4(hostPort.host)) {
        throw new Error(`host_port ${JSON.stringify(target)} is not an IPv4 address`);
    }
    if (scheme === 'ipv6' && !isIPv6(hostPort.host)) {
        throw new Error(`host_port ${JSON.stringify(target)} is not an IPv6 address`);
    }
    return { host: hostPort.host, port: (_a = hostPort.port) !== null && _a !== void 0 ? _a : DEFAULT_PORT, authority: address };
}
/** The base URL Connect dials for a target: an IPv6 host is bracketed as a URL requires. */
function grpcTargetBaseUrl(target, protocol) {
    const host = target.host.includes(':') ? `[${target.host}]` : target.host;
    return `${protocol}://${host}:${target.port}`;
}
/*
 * grpc-js's host:port split: a bracketed host is IPv6 with an optional `:port`, exactly one
 * colon separates a host from a numeric port, and any other number of colons is a bare IPv6
 * address with no port.
 */
function splitHostPort(address) {
    if (address.startsWith('[')) {
        const end = address.indexOf(']');
        if (end === -1) {
            return null;
        }
        const host = address.slice(1, end);
        if (!host.includes(':')) {
            return null;
        }
        const rest = address.slice(end + 1);
        if (rest === '') {
            return { host };
        }
        if (rest.startsWith(':') && /^\d+$/.test(rest.slice(1))) {
            return { host, port: Number(rest.slice(1)) };
        }
        return null;
    }
    const parts = address.split(':');
    if (parts.length === 2) {
        return /^\d+$/.test(parts[1]) ? { host: parts[0], port: Number(parts[1]) } : null;
    }
    return { host: address };
}
