"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_MAX_MESSAGE_BYTES = void 0;
exports.createAuthInterceptor = createAuthInterceptor;
/**
 * The largest message either transport accepts or sends unless configured otherwise: the
 * grpc-js default the `grpc_max_recv_message_length` and `grpc_max_send_message_length`
 * settings override.
 */
exports.DEFAULT_MAX_MESSAGE_BYTES = 4 * 1024 * 1024;
/**
 * The characters a token may contain and still travel in an HTTP header: the printable ASCII
 * range, which is also what grpc-js accepts in metadata. Anything else would make the header
 * layer reject the request with an error quoting the token.
 */
const HEADER_SAFE = /^[ -~]*$/;
/**
 * Sets the bearer token the engine authenticates every call with. The transport applies it to
 * each request, so callers never pass credentials per call. A token that cannot be carried in a
 * header is refused here with a fixed message, so the token's value never reaches a log or an
 * error.
 */
function createAuthInterceptor(token) {
    if (!HEADER_SAFE.test(token)) {
        throw new Error('The Hatchet client token contains characters that cannot be sent in an HTTP header; check HATCHET_CLIENT_TOKEN for stray whitespace or line breaks');
    }
    return (next) => (req) => {
        req.header.set('authorization', `Bearer ${token}`);
        return next(req);
    };
}
